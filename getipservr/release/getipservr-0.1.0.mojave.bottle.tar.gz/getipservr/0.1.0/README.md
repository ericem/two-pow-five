# Get Your IP Server (getipservr)

## What is it?

The getipservr application is a web service that when queried returns the IP address of the client making the request. It is similar to services like whatsmyip.org, but is more secure and can be self-hosted. So, what is the use case for getipservr? It can be used as the basis for a secure version of a dynamic DNS client. There are several dynamic DNS providers like noip.com and dyn.com that provide a DNS service that allow dynamic updates of A records through a client. Sometimes these clients are built into home routers, but if you are using your own Linux or BSD servers behind your home router you may prefer a more secure custom built client. In this scenario you could run getipservr on a small cloud virtual machine, to provide the client the IP address on the external interface of your home router, which can then update the DNS record with your dynamic DNS provider. The getipserver provides a few extra security benefits, 1) it uses TLS to encrypt the session to ensure the IP address is not modifed in transit, 2) it uses authentication with long securely generated secrets that can be genereated by getipserver, 3) it uses TOTP (one-time-passwords) tokens so that a client can verify a response from the getipserver is valid.


## Install Using Homebrew

```
brew tap ericem/two-pow-five
brew install getipservr
```

## Install From Source

### Install Build Requirements

Install the compiler:

```
brew install crystal
```

### Compiling

To build a debug version:

```
make
```

To build a release:

```
make release
```

To build and install the binary:
```
make install
```


## Usage


### Generate secrets

The getipservr has a built in method to generate secret keys for the authentication or for use with the TOTP token generator.

Generate a secret:

```
getipservr secret
```

### Start getipservr

The server requires 3 paramters set through environment variables:

* GETIP_SECRET - the secret used to authenticate a client
* GETIP_KEY - the username used to identify an client
* GETIP_TOTPSECRET - the secret used to generate/verify a one-time-password token 

Start the server:

```
GETIP_KEY=KEY GETIP_SECRET=SECRET GETIP_TOTPSECRET=SECRET getipservr
```

The getipservr should be used with TLS security enabled. If you don't have a security from one of the TLS providers like "Let's Encrypt", you can use my previous project **certgen** to create a self-signed certficate.

To Enable TLS:
```
getipserver --ssl --ssl-key-file FILE --ssl-cert-file FILE
```

The getipservr uses port 3000 by default, but can be changed.

To Change the default port:
```
getipserver -p PORT
```

